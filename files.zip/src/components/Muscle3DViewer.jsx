import { useEffect, useRef } from 'react'
import * as THREE from 'three'
import { motion } from 'framer-motion'

export const Muscle3DViewer = ({ onMuscleClick, activeExerciseMuscles = [] }) => {
  const containerRef = useRef(null)
  const sceneRef = useRef(null)
  const cameraRef = useRef(null)
  const rendererRef = useRef(null)
  const bodyGroupRef = useRef(null)

  useEffect(() => {
    if (!containerRef.current) return

    const scene = new THREE.Scene()
    sceneRef.current = scene
    scene.background = new THREE.Color(0x000000)
    scene.fog = new THREE.Fog(0x000000, 100, 1000)

    const camera = new THREE.PerspectiveCamera(
      75,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000
    )
    camera.position.z = 3
    cameraRef.current = camera

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight)
    renderer.setPixelRatio(window.devicePixelRatio)
    containerRef.current.appendChild(renderer.domElement)
    rendererRef.current = renderer

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5)
    scene.add(ambientLight)

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8)
    directionalLight.position.set(5, 5, 5)
    scene.add(directionalLight)

    const pointLight = new THREE.PointLight(0x0066FF, 0.3)
    pointLight.position.set(0, 0, 3)
    scene.add(pointLight)

    const bodyGroup = new THREE.Group()
    bodyGroupRef.current = bodyGroup
    scene.add(bodyGroup)

    // Head
    const headGeometry = new THREE.SphereGeometry(0.3, 32, 32)
    const headMaterial = new THREE.MeshStandardMaterial({
      color: 0x2a2a2a,
      metalness: 0.1,
      roughness: 0.8,
    })
    const head = new THREE.Mesh(headGeometry, headMaterial)
    head.position.y = 1.3
    head.userData.muscle = 'head'
    bodyGroup.add(head)

    // Torso/Chest
    const torsoGeometry = new THREE.BoxGeometry(0.5, 0.8, 0.3)
    const torsoMaterial = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      metalness: 0.2,
      roughness: 0.8,
    })
    const torso = new THREE.Mesh(torsoGeometry, torsoMaterial)
    torso.position.y = 0.6
    torso.userData.muscle = 'chest'
    bodyGroup.add(torso)

    // Back
    const backGeometry = new THREE.BoxGeometry(0.5, 0.6, 0.25)
    const backMaterial = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      metalness: 0.2,
      roughness: 0.8,
    })
    const back = new THREE.Mesh(backGeometry, backMaterial)
    back.position.set(0, 0.8, -0.3)
    back.userData.muscle = 'back'
    bodyGroup.add(back)

    // Shoulders
    const shoulderGeometry = new THREE.SphereGeometry(0.2, 16, 16)
    const shoulderMaterial = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      metalness: 0.15,
      roughness: 0.8,
    })

    const leftShoulder = new THREE.Mesh(shoulderGeometry, shoulderMaterial)
    leftShoulder.position.set(-0.35, 1.1, 0)
    leftShoulder.userData.muscle = 'shoulders'
    bodyGroup.add(leftShoulder)

    const rightShoulder = new THREE.Mesh(shoulderGeometry, shoulderMaterial)
    rightShoulder.position.set(0.35, 1.1, 0)
    rightShoulder.userData.muscle = 'shoulders'
    bodyGroup.add(rightShoulder)

    // Left arm
    const armGeometry = new THREE.BoxGeometry(0.15, 0.7, 0.15)
    const armMaterial = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      metalness: 0.1,
      roughness: 0.8,
    })

    const leftArm = new THREE.Mesh(armGeometry, armMaterial)
    leftArm.position.set(-0.5, 0.6, 0)
    leftArm.userData.muscle = 'biceps'
    bodyGroup.add(leftArm)

    // Right arm
    const rightArm = new THREE.Mesh(armGeometry, armMaterial)
    rightArm.position.set(0.5, 0.6, 0)
    rightArm.userData.muscle = 'biceps'
    bodyGroup.add(rightArm)

    // Left tricep
    const leftTricep = new THREE.Mesh(
      new THREE.BoxGeometry(0.12, 0.65, 0.12),
      new THREE.MeshStandardMaterial({
        color: 0x1a1a1a,
        metalness: 0.1,
        roughness: 0.8,
      })
    )
    leftTricep.position.set(-0.53, 0.55, 0.15)
    leftTricep.userData.muscle = 'triceps'
    bodyGroup.add(leftTricep)

    // Right tricep
    const rightTricep = new THREE.Mesh(
      new THREE.BoxGeometry(0.12, 0.65, 0.12),
      new THREE.MeshStandardMaterial({
        color: 0x1a1a1a,
        metalness: 0.1,
        roughness: 0.8,
      })
    )
    rightTricep.position.set(0.53, 0.55, 0.15)
    rightTricep.userData.muscle = 'triceps'
    bodyGroup.add(rightTricep)

    // Abs
    const absGeometry = new THREE.BoxGeometry(0.35, 0.5, 0.25)
    const absMaterial = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      metalness: 0.15,
      roughness: 0.8,
    })
    const abs = new THREE.Mesh(absGeometry, absMaterial)
    abs.position.y = 0.2
    abs.userData.muscle = 'abs'
    bodyGroup.add(abs)

    // Left leg
    const legGeometry = new THREE.BoxGeometry(0.2, 0.8, 0.2)
    const legMaterial = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      metalness: 0.1,
      roughness: 0.8,
    })

    const leftLeg = new THREE.Mesh(legGeometry, legMaterial)
    leftLeg.position.set(-0.15, -0.5, 0)
    leftLeg.userData.muscle = 'quads'
    bodyGroup.add(leftLeg)

    // Right leg
    const rightLeg = new THREE.Mesh(legGeometry, legMaterial)
    rightLeg.position.set(0.15, -0.5, 0)
    rightLeg.userData.muscle = 'quads'
    bodyGroup.add(rightLeg)

    // Left hamstring
    const hamstringGeometry = new THREE.BoxGeometry(0.18, 0.75, 0.18)
    const hamstringMaterial = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      metalness: 0.1,
      roughness: 0.8,
    })

    const leftHamstring = new THREE.Mesh(hamstringGeometry, hamstringMaterial)
    leftHamstring.position.set(-0.18, -0.52, 0.2)
    leftHamstring.userData.muscle = 'hamstrings'
    bodyGroup.add(leftHamstring)

    // Right hamstring
    const rightHamstring = new THREE.Mesh(hamstringGeometry, hamstringMaterial)
    rightHamstring.position.set(0.18, -0.52, 0.2)
    rightHamstring.userData.muscle = 'hamstrings'
    bodyGroup.add(rightHamstring)

    // Glutes
    const gluteGeometry = new THREE.BoxGeometry(0.4, 0.35, 0.25)
    const gluteMaterial = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      metalness: 0.1,
      roughness: 0.8,
    })
    const glute = new THREE.Mesh(gluteGeometry, gluteMaterial)
    glute.position.set(0, -0.1, -0.35)
    glute.userData.muscle = 'glutes'
    bodyGroup.add(glute)

    // Raycaster
    const raycaster = new THREE.Raycaster()
    const mouse = new THREE.Vector2()

    const onMouseClick = (event) => {
      mouse.x = (event.clientX / window.innerWidth) * 2 - 1
      mouse.y = -(event.clientY / window.innerHeight) * 2 + 1

      raycaster.setFromCamera(mouse, camera)
      const intersects = raycaster.intersectObjects(bodyGroup.children)

      if (intersects.length > 0) {
        const muscle = intersects[0].object.userData.muscle
        if (muscle && onMuscleClick) {
          onMuscleClick(muscle)
        }
      }
    }

    renderer.domElement.addEventListener('click', onMouseClick)

    let animationFrameId
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate)

      bodyGroup.rotation.y += 0.003

      bodyGroup.children.forEach((mesh) => {
        const muscle = mesh.userData.muscle
        if (activeExerciseMuscles.includes(muscle)) {
          mesh.material.emissive = new THREE.Color(0x0066FF)
          mesh.material.emissiveIntensity = 0.4
        } else {
          mesh.material.emissive = new THREE.Color(0x000000)
          mesh.material.emissiveIntensity = 0
        }
      })

      renderer.render(scene, camera)
    }
    animate()

    const handleResize = () => {
      if (!containerRef.current) return
      const width = containerRef.current.clientWidth
      const height = containerRef.current.clientHeight
      camera.aspect = width / height
      camera.updateProjectionMatrix()
      renderer.setSize(width, height)
    }
    window.addEventListener('resize', handleResize)

    return () => {
      window.removeEventListener('resize', handleResize)
      renderer.domElement.removeEventListener('click', onMouseClick)
      cancelAnimationFrame(animationFrameId)
      renderer.dispose()
      if (containerRef.current && renderer.domElement.parentNode === containerRef.current) {
        containerRef.current.removeChild(renderer.domElement)
      }
    }
  }, [onMuscleClick, activeExerciseMuscles])

  return (
    <motion.div
      className="relative w-full h-[500px] rounded-2xl glass overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
    >
      <div ref={containerRef} className="w-full h-full" />
      <div className="absolute top-4 left-4 text-xs text-white/50 font-semibold">
        Click on body parts to see exercises
      </div>
    </motion.div>
  )
}