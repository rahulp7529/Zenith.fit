import { motion, AnimatePresence } from 'framer-motion'
import { panelVariants } from '../utils/animations'

export const MusclePanel = ({ selectedMuscle, exercises, muscleData, onClose }) => {
  if (!selectedMuscle) return null

  const muscleExercises = exercises[selectedMuscle] || []

  return (
    <AnimatePresence>
      {selectedMuscle && (
        <>
          <motion.div
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40"
            onClick={onClose}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          />

          <motion.div
            className="fixed bottom-0 left-0 right-0 z-50 rounded-t-3xl glass max-h-[80vh] overflow-y-auto"
            variants={panelVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-white capitalize">
                    {selectedMuscle}
                  </h2>
                  <p className="text-sm text-white/50 mt-1">
                    Exercises targeting this muscle
                  </p>
                </div>
                <motion.button
                  onClick={onClose}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/70 hover:text-white hover:bg-white/20 transition-colors"
                >
                  ✕
                </motion.button>
              </div>

              <div className="grid grid-cols-1 gap-3">
                {muscleExercises.length > 0 ? (
                  muscleExercises.map((exercise, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="p-4 rounded-xl bg-electric-blue/5 border border-electric-blue/20 hover:border-electric-blue/50 transition-all cursor-pointer group"
                    >
                      <p className="text-white font-semibold group-hover:text-electric-blue transition-colors">
                        {exercise}
                      </p>
                      <p className="text-xs text-white/50 mt-1 capitalize">
                        {selectedMuscle} builder
                      </p>
                    </motion.div>
                  ))
                ) : (
                  <p className="text-white/50 py-8 text-center">
                    No exercises found for this muscle.
                  </p>
                )}
              </div>

              <div className="mt-8 pt-6 border-t border-white/5">
                <p className="text-xs text-white/40 text-center">
                  Tap an exercise to add it to your workout
                </p>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}