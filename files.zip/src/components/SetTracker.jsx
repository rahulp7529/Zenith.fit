import { motion } from 'framer-motion'
import { checkboxVariants, itemVariants } from '../utils/animations'

export const SetTracker = ({
  exercise,
  onToggleSet,
  isSetCompleted,
  progress,
}) => {
  return (
    <motion.div
      className="mt-6 space-y-3"
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="px-1 py-2">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-semibold text-white">Set Tracker</h4>
          <span className="text-xs text-electric-blue font-medium">
            {progress?.completed} / {progress?.total} completed
          </span>
        </div>

        <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden mb-4">
          <motion.div
            className="h-full bg-gradient-to-r from-electric-blue via-electric-blue to-electric-blue/60 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${progress?.percentage || 0}%` }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
          />
        </div>

        <div className="space-y-2">
          {exercise.sets.map((set) => {
            const completed = isSetCompleted(exercise.id, set.id)
            return (
              <motion.div
                key={set.id}
                variants={itemVariants}
                className={`flex items-center gap-3 p-3 rounded-lg glass transition-all ${
                  completed
                    ? 'bg-electric-blue/5 border border-electric-blue/30'
                    : 'border border-white/5'
                }`}
              >
                <motion.button
                  variants={checkboxVariants}
                  animate={completed ? 'checked' : 'unchecked'}
                  onClick={() => onToggleSet(exercise.id, set.id)}
                  className={`relative w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 transition-colors ${
                    completed
                      ? 'bg-electric-blue border-electric-blue'
                      : 'border-white/30 hover:border-white/50'
                  }`}
                >
                  {completed && (
                    <motion.svg
                      className="w-3 h-3 text-dark-bg"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ duration: 0.2 }}
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={3}
                        d="M5 13l4 4L19 7"
                      />
                    </motion.svg>
                  )}
                </motion.button>

                <div className="flex-1">
                  <p
                    className={`font-medium text-sm transition-all ${
                      completed
                        ? 'text-white/50 line-through'
                        : 'text-white'
                    }`}
                  >
                    Set {set.id}
                  </p>
                </div>

                <span
                  className={`text-sm font-semibold px-3 py-1 rounded-lg transition-all ${
                    completed
                      ? 'bg-electric-blue/20 text-electric-blue/60'
                      : 'bg-white/5 text-white/70'
                  }`}
                >
                  {set.reps} reps
                </span>
              </motion.div>
            )
          })}
        </div>
      </div>
    </motion.div>
  )
}