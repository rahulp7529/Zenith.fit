import { motion } from 'framer-motion'
import { cardHoverVariants, itemVariants } from '../utils/animations'

export const ExerciseCard = ({
  exercise,
  isActive,
  onSelect,
  progress,
}) => {
  return (
    <motion.div
      variants={itemVariants}
      whileHover="hover"
      whileTap={{ scale: 0.98 }}
      initial="rest"
      animate="rest"
    >
      <button
        onClick={() => onSelect(exercise)}
        className={`w-full p-5 rounded-2xl glass transition-all ${
          isActive
            ? 'ring-2 ring-electric-blue/50 bg-white/8'
            : 'hover:bg-white/6'
        }`}
      >
        <div className="flex items-start justify-between gap-4">
          <div className="text-left flex-1">
            <h3 className="font-bold text-base text-white mb-2">
              {exercise.name}
            </h3>
            <p className="text-sm text-white/60">
              {exercise.sets.length} × {exercise.sets[0]?.reps} reps
            </p>
            <div className="mt-3 flex gap-2 flex-wrap">
              {exercise.muscles.map((muscle) => (
                <span
                  key={muscle}
                  className="text-xs px-2 py-1 rounded-full bg-electric-blue/10 text-electric-blue/70 capitalize"
                >
                  {muscle}
                </span>
              ))}
            </div>
          </div>

          <div className="flex flex-col items-end gap-2">
            <div className="text-right">
              <p className="text-xs text-white/50">
                {progress?.completed}/{progress?.total}
              </p>
              <p className="text-xs font-semibold text-electric-blue">
                {progress?.percentage || 0}%
              </p>
            </div>
            <div className="w-12 h-1 bg-white/10 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-electric-blue to-electric-blue/60"
                initial={{ width: 0 }}
                animate={{ width: `${progress?.percentage || 0}%` }}
                transition={{ duration: 0.6, ease: 'easeOut' }}
              />
            </div>
          </div>
        </div>
      </button>
    </motion.div>
  )
}