import { motion } from 'framer-motion'

export const DaySelector = ({ days, activeDay, onDayChange }) => {
  return (
    <div className="sticky top-0 z-40 bg-dark-bg/80 backdrop-blur-sm border-b border-white/5 py-4 px-6">
      <div className="flex gap-3 overflow-x-auto pb-2">
        {days.map((day) => (
          <motion.button
            key={day.id}
            onClick={() => onDayChange(day.id)}
            className={`relative px-6 py-2 rounded-2xl font-semibold text-sm whitespace-nowrap transition-all ${
              activeDay === day.id
                ? 'glass glow-blue text-electric-blue'
                : 'text-white/60 hover:text-white/80'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <span className="mr-2">{day.emoji}</span>
            {day.name}
            {activeDay === day.id && (
              <motion.div
                className="absolute inset-0 rounded-2xl border border-electric-blue/50"
                layoutId="activeDay"
                transition={{ duration: 0.3 }}
              />
            )}
          </motion.button>
        ))}
      </div>
      <div className="mt-2 h-0.5 bg-gradient-to-r from-electric-blue/0 via-electric-blue/20 to-electric-blue/0" />
    </div>
  )
}