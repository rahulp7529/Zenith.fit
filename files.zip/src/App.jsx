import { useEffect, useState } from 'react'
import Dashboard from './pages/Dashboard'
import { motion } from 'framer-motion'

function App() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate initial load
    setTimeout(() => setIsLoading(false), 300)
  }, [])

  if (isLoading) {
    return (
      <div className="w-full h-screen bg-dark-bg flex items-center justify-center">
        <motion.div
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="text-electric-blue text-2xl font-bold"
        >
          GymFlow
        </motion.div>
      </div>
    )
  }

  return <Dashboard />
}

export default App