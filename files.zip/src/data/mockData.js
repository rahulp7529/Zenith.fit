export const mockWorkoutData = {
  days: [
    {
      id: 'push',
      name: 'Push',
      emoji: '📤',
      exercises: [
        {
          id: 'incline-db-press',
          name: 'Incline Dumbbell Press',
          sets: [
            { id: 1, reps: 10, completed: false },
            { id: 2, reps: 8, completed: false },
            { id: 3, reps: 8, completed: false },
          ],
          muscles: ['chest', 'shoulders', 'triceps'],
          difficulty: 'hard',
        },
        {
          id: 'flat-bench-press',
          name: 'Flat Bench Press',
          sets: [
            { id: 1, reps: 12, completed: false },
            { id: 2, reps: 10, completed: false },
            { id: 3, reps: 8, completed: false },
          ],
          muscles: ['chest', 'triceps'],
          difficulty: 'hard',
        },
        {
          id: 'shoulder-press',
          name: 'Shoulder Press',
          sets: [
            { id: 1, reps: 10, completed: false },
            { id: 2, reps: 8, completed: false },
            { id: 3, reps: 8, completed: false },
          ],
          muscles: ['shoulders', 'triceps'],
          difficulty: 'medium',
        },
        {
          id: 'tricep-dips',
          name: 'Tricep Dips',
          sets: [
            { id: 1, reps: 12, completed: false },
            { id: 2, reps: 10, completed: false },
          ],
          muscles: ['triceps', 'chest'],
          difficulty: 'medium',
        },
      ],
    },
    {
      id: 'pull',
      name: 'Pull',
      emoji: '📥',
      exercises: [
        {
          id: 'pull-ups',
          name: 'Pull Ups',
          sets: [
            { id: 1, reps: 8, completed: false },
            { id: 2, reps: 7, completed: false },
            { id: 3, reps: 6, completed: false },
          ],
          muscles: ['back', 'biceps'],
          difficulty: 'hard',
        },
        {
          id: 'barbell-rows',
          name: 'Barbell Rows',
          sets: [
            { id: 1, reps: 8, completed: false },
            { id: 2, reps: 8, completed: false },
            { id: 3, reps: 8, completed: false },
          ],
          muscles: ['back', 'biceps'],
          difficulty: 'hard',
        },
        {
          id: 'lat-pulldown',
          name: 'Lat Pulldown',
          sets: [
            { id: 1, reps: 12, completed: false },
            { id: 2, reps: 10, completed: false },
            { id: 3, reps: 8, completed: false },
          ],
          muscles: ['back', 'biceps'],
          difficulty: 'medium',
        },
        {
          id: 'bicep-curls',
          name: 'Bicep Curls',
          sets: [
            { id: 1, reps: 12, completed: false },
            { id: 2, reps: 10, completed: false },
            { id: 3, reps: 8, completed: false },
          ],
          muscles: ['biceps'],
          difficulty: 'easy',
        },
      ],
    },
    {
      id: 'legs',
      name: 'Legs',
      emoji: '🦵',
      exercises: [
        {
          id: 'squats',
          name: 'Barbell Squats',
          sets: [
            { id: 1, reps: 8, completed: false },
            { id: 2, reps: 8, completed: false },
            { id: 3, reps: 8, completed: false },
          ],
          muscles: ['quads', 'glutes', 'hamstrings'],
          difficulty: 'hard',
        },
        {
          id: 'deadlifts',
          name: 'Deadlifts',
          sets: [
            { id: 1, reps: 5, completed: false },
            { id: 2, reps: 5, completed: false },
            { id: 3, reps: 5, completed: false },
          ],
          muscles: ['hamstrings', 'glutes', 'back'],
          difficulty: 'hard',
        },
        {
          id: 'leg-press',
          name: 'Leg Press',
          sets: [
            { id: 1, reps: 12, completed: false },
            { id: 2, reps: 10, completed: false },
            { id: 3, reps: 8, completed: false },
          ],
          muscles: ['quads', 'glutes'],
          difficulty: 'medium',
        },
        {
          id: 'leg-curls',
          name: 'Leg Curls',
          sets: [
            { id: 1, reps: 12, completed: false },
            { id: 2, reps: 12, completed: false },
            { id: 3, reps: 10, completed: false },
          ],
          muscles: ['hamstrings'],
          difficulty: 'easy',
        },
      ],
    },
  ],

  muscleExercises: {
    chest: ['Bench Press', 'Incline Press', 'Chest Fly', 'Cable Crossover'],
    back: ['Pull Ups', 'Barbell Rows', 'Lat Pulldown', 'Face Pulls'],
    shoulders: ['Shoulder Press', 'Lateral Raises', 'Reverse Fly', 'Upright Rows'],
    biceps: ['Bicep Curls', 'Pull Ups', 'Barbell Rows', 'Lat Pulldown'],
    triceps: ['Tricep Dips', 'Rope Extensions', 'Close Grip Press', 'Overhead Extension'],
    quads: ['Squats', 'Leg Press', 'Leg Extensions', 'Walking Lunges'],
    hamstrings: ['Deadlifts', 'Leg Curls', 'Squats', 'Romanian Deadlifts'],
    glutes: ['Squats', 'Deadlifts', 'Hip Thrusts', 'Leg Press'],
  },

  muscleColor: {
    chest: '#0066FF',
    back: '#0066FF',
    shoulders: '#0066FF',
    biceps: '#0066FF',
    triceps: '#0066FF',
    quads: '#0066FF',
    hamstrings: '#0066FF',
    glutes: '#0066FF',
  },
}