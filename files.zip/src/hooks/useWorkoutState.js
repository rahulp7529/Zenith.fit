import { useState, useCallback } from 'react'

export const useWorkoutState = (initialData) => {
  const [completedSets, setCompletedSets] = useState({})
  const [activeExercise, setActiveExercise] = useState(null)
  const [selectedMuscle, setSelectedMuscle] = useState(null)

  const toggleSetCompletion = useCallback((exerciseId, setId) => {
    setCompletedSets((prev) => {
      const key = `${exerciseId}-${setId}`
      return {
        ...prev,
        [key]: !prev[key],
      }
    })
  }, [])

  const isSetCompleted = useCallback((exerciseId, setId) => {
    return completedSets[`${exerciseId}-${setId}`] || false
  }, [completedSets])

  const getExerciseProgress = useCallback((exercise) => {
    const completed = exercise.sets.filter((set) =>
      isSetCompleted(exercise.id, set.id)
    ).length
    return {
      completed,
      total: exercise.sets.length,
      percentage: Math.round((completed / exercise.sets.length) * 100),
    }
  }, [isSetCompleted])

  return {
    completedSets,
    activeExercise,
    selectedMuscle,
    toggleSetCompletion,
    isSetCompleted,
    getExerciseProgress,
    setActiveExercise,
    setSelectedMuscle,
  }
}