export const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
}

export const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: 'easeOut' },
  },
}

export const cardHoverVariants = {
  rest: { scale: 1, boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)' },
  hover: {
    scale: 1.02,
    boxShadow: '0 0 20px rgba(0, 102, 255, 0.2)',
    transition: { duration: 0.2 },
  },
}

export const checkboxVariants = {
  unchecked: { scale: 1, opacity: 0.6 },
  checked: {
    scale: 1.1,
    opacity: 1,
    transition: { duration: 0.2 },
  },
}

export const muscleGlowVariants = {
  rest: { opacity: 0.5 },
  hover: {
    opacity: 1,
    boxShadow: '0 0 30px rgba(0, 102, 255, 0.6)',
    transition: { duration: 0.3 },
  },
}

export const panelVariants = {
  hidden: { opacity: 0, y: 100 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, ease: 'easeOut' },
  },
  exit: {
    opacity: 0,
    y: 100,
    transition: { duration: 0.3, ease: 'easeIn' },
  },
}