import { useState, useMemo } from 'react'
import { motion } from 'framer-motion'
import { Layout } from '../components/Layout'
import { DaySelector } from '../components/DaySelector'
import { ExerciseCard } from '../components/ExerciseCard'
import { SetTracker } from '../components/SetTracker'
import { Muscle3DViewer } from '../components/Muscle3DViewer'
import { MusclePanel } from '../components/MusclePanel'
import { useWorkoutState } from '../hooks/useWorkoutState'
import { mockWorkoutData } from '../data/mockData'
import { containerVariants } from '../utils/animations'

export default function Dashboard() {
  const [activeDay, setActiveDay] = useState('push')
  const {
    activeExercise,
    selectedMuscle,
    toggleSetCompletion,
    isSetCompleted,
    getExerciseProgress,
    setActiveExercise,
    setSelectedMuscle,
  } = useWorkoutState(mockWorkoutData)

  const currentDayData = useMemo(() => {
    return mockWorkoutData.days.find((day) => day.id === activeDay)
  }, [activeDay])

  const handleDayChange = (dayId) => {
    setActiveDay(dayId)
    setActiveExercise(null)
    setSelectedMuscle(null)
  }

  const handleMuscleClick = (muscle) => {
    setSelectedMuscle(muscle)
  }

  const activeExerciseMuscles = activeExercise?.muscles || []

  return (
    <Layout>
      <div className="min-h-screen bg-dark-bg flex flex-col">
        <div className="px-6 pt-6 pb-4">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl font-bold text-white mb-1">GymFlow</h1>
            <p className="text-white/50 text-sm">
              Premium workout tracking × 3D visualization
            </p>
          </motion.div>
        </div>

        <DaySelector
          days={mockWorkoutData.days}
          activeDay={activeDay}
          onDayChange={handleDayChange}
        />

        <div className="flex-1 px-6 py-6 overflow-y-auto space-y-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            key={`viewer-${activeDay}`}
          >
            <Muscle3DViewer
              onMuscleClick={handleMuscleClick}
              activeExerciseMuscles={activeExerciseMuscles}
            />
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            key={`exercises-${activeDay}`}
          >
            <h2 className="text-xl font-bold text-white mb-4 px-1">
              Exercises for {currentDayData?.name}
            </h2>
            <div className="space-y-3">
              {currentDayData?.exercises.map((exercise) => {
                const progress = getExerciseProgress(exercise)
                const isActive = activeExercise?.id === exercise.id

                return (
                  <div key={exercise.id}>
                    <ExerciseCard
                      exercise={exercise}
                      isActive={isActive}
                      onSelect={setActiveExercise}
                      progress={progress}
                    />

                    {isActive && (
                      <SetTracker
                        exercise={exercise}
                        onToggleSet={toggleSetCompletion}
                        isSetCompleted={isSetCompleted}
                        progress={progress}
                      />
                    )}
                  </div>
                )
              })}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="sticky bottom-0 bg-gradient-to-t from-dark-bg via-dark-bg to-transparent pt-6 pb-6"
          >
            <div className="glass p-4 rounded-2xl text-center">
              <p className="text-sm text-white/60 mb-2">
                {currentDayData?.name} Day Progress
              </p>
              <div className="text-2xl font-bold text-electric-blue">
                {currentDayData?.exercises.reduce(
                  (total, ex) => total + getExerciseProgress(ex).completed,
                  0
                ) || 0}
                {' '}
                /
                {' '}
                {currentDayData?.exercises.reduce(
                  (total, ex) => total + ex.sets.length,
                  0
                ) || 0}
                {' '}
                Sets Complete
              </div>
            </div>
          </motion.div>

          <div className="h-24" />
        </div>
      </div>

      <MusclePanel
        selectedMuscle={selectedMuscle}
        exercises={mockWorkoutData.muscleExercises}
        muscleData={mockWorkoutData.muscleColor}
        onClose={() => setSelectedMuscle(null)}
      />
    </Layout>
  )
}